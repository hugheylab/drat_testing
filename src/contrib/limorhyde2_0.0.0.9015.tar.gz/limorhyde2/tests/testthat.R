library(testthat)
library(limorhyde2)

test_check("limorhyde2")
