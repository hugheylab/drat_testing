## ---- echo = FALSE-------------------------------------------------------
knitr::opts_chunk$set(message = FALSE, collapse = TRUE, comment = '#>', fig.retina = 2)

## ------------------------------------------------------------------------
library(data.table)
library(ggplot2)
library(kableExtra)
library(knitr)
library(limma)
library(precrec)
library(simphony)

## ------------------------------------------------------------------------
set.seed(44)
exprGroups = data.table(fracGenes = c(0.75, 0.25), amp = c(0, 0.3))
simData = simphony(exprGroups, nGenes = 200, interval = 2, nReps = 1, family = 'negbinom')

## ------------------------------------------------------------------------
kable(simData$exprData[1:3, 1:3])

## ------------------------------------------------------------------------
kable(simData$sampleMetadata[1:3,])

## ------------------------------------------------------------------------
kable(simData$geneMetadata[149:151,]) %>%
  kable_styling(font_size = 12)

## ------------------------------------------------------------------------
gmExample = simData$geneMetadata[gene %in% c('gene_150', 'gene_151')]
dExample = mergeSimData(simData, gmExample$gene)

## ------------------------------------------------------------------------
dExpect = getExpectedExpr(gmExample, 24, times = seq(0, 24, 0.25))

## ---- fig.width = 6, fig.height = 2.75-----------------------------------
dExample[, geneLabel := paste(gene, ifelse(amp == 0, '(non-rhythmic)', '(rhythmic)'))]
dExpect[, geneLabel := paste(gene, ifelse(amp == 0, '(non-rhythmic)', '(rhythmic)'))]

ggplot(dExample) +
  facet_wrap(~ geneLabel, nrow = 1) +
  geom_line(aes(x = time, y = log2(2^mu + 1)), size = 0.25, data = dExpect) +
  geom_point(aes(x = time, y = log2(expr + 1)), shape = 21, size = 2.5) +
  labs(x = 'Time (h)', y = expression(log[2](counts+1))) +
  scale_x_continuous(limits = c(0, 24), breaks = seq(0, 24, 4))

## ------------------------------------------------------------------------
sampleMetadata = copy(simData$sampleMetadata)
sampleMetadata[, timeCos := cos(time * 2*pi / 24)]
sampleMetadata[, timeSin := sin(time * 2*pi / 24)]
design = model.matrix(~ timeCos + timeSin, data = sampleMetadata)

## ------------------------------------------------------------------------
fit = lmFit(log2(simData$exprData + 1), design)
fit = eBayes(fit, trend = TRUE)
rhyLimma = topTable(fit, coef = 2:3, number = Inf)

## ------------------------------------------------------------------------
rhyLimma$gene = rownames(rhyLimma)
rhyLimma = merge(data.table(rhyLimma), simData$geneMetadata[, .(gene, amp)], by = 'gene')

## ---- fig.width = 3.5, fig.height = 3------------------------------------
ggplot(rhyLimma) +
  geom_jitter(aes(x = factor(amp), y = P.Value), shape = 21, width = 0.2) +
  labs(x = expression('Rhythm amplitude '*(log[2]~counts)), y = 'P-value of rhythmicity')

## ---- fig.width = 3, fig.height = 3--------------------------------------
rocprc = evalmod(scores = -log(rhyLimma$P.Value), labels = rhyLimma$amp > 0)
autoplot(rocprc, 'ROC')

