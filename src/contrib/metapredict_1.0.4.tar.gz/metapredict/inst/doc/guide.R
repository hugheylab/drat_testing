## ---- echo = FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ---- eval = FALSE------------------------------------------------------------
#  ?metapredict::installCustomCdfPackages

## ---- eval = FALSE------------------------------------------------------------
#  ?metapredict::downloadCustomCdfMappings

## ---- eval = FALSE------------------------------------------------------------
#  studyMetadata = read.csv('<path to study metadata file>', stringsAsFactors = FALSE)
#  metapredict::getUnsupportedPlatforms(studyMetadata)

