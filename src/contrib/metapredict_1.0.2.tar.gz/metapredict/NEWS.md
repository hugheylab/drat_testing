# metapredict 1.0.2
- Vignettes now properly link to each other and to documentation.

# metapredict 1.0.1
- Added `pkgdown` site.
- Updated roxygen-based documentation.
- `installCustomCdfPackages` now uses latest BrainArray version.
- `metapredict` now works with updated `glmnet::predict.glmnet`.
